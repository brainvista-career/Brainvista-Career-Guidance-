BRAINVISTA CAREER GUIDANCE — FREE WEBSITE

Open index.html to preview the complete website.

The site includes:
- Responsive mobile + desktop design
- Founder section with photo
- Child Potential Coaching
- Career Counselling
- India Admissions
- Study Abroad Counselling
- Course & College Selection
- Free 20-minute consultation CTA
- Click-to-call, email and WhatsApp
- Quick enquiry form that opens a pre-filled WhatsApp message

To publish free: upload index.html to a static hosting service such as GitHub Pages, Netlify or Cloudflare Pages.

The founder photo was cropped from the screenshot supplied in the conversation. Replace priyanka-pandey.jpg with the original high-resolution photo later for a sharper result.
